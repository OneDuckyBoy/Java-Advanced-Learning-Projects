package workshop_2_LinkedList;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class DoublyLinkedList {

    private Node head;
    private Node tail;
    private int size;

    public void addFirst(int number){
        Node newNode = new Node(number);
        if (!isEmpty()){
            newNode.next = head;
            head.prev = newNode;
        }else {
            tail = newNode;
        }
        head = newNode;
        size++;
    }

    public int removeFirst(){
        if (isEmpty()){
            throw new IllegalStateException("Can`t remove from empty list");
        }
        int result = head.value;
        size--;
        head = head.next;
        if (this.size>1){
            head.prev = null;
        }
        if (isEmpty()){
            head = null;
            tail = null;
        }
        return result;
    }

    public void addLast(int number){
        if (isEmpty()){
            addFirst(number);
            return;
        }
        Node newNode = new Node(number);
        newNode.prev = tail;
        tail.next = newNode;
        tail = newNode;
        size++;
    }

    public int removeLast(){

        if (size<2){
            return removeFirst();
        }int result =tail.value;
        tail.next = null;
        this.size--;
        return result;
    }

    public int get(int searchIndex){
        checkIndex(searchIndex);
        int currIndex = 0;
        Node currNode;
        if (searchIndex>size/2){
            currNode= tail;
            int lastIndex = size-1;
            int coundOfIterations = lastIndex-searchIndex;
            for (int i = 0; i < coundOfIterations; i++) {
                currNode = currNode.prev;
            }
        }else {
            currNode = head;
            while (currIndex<searchIndex){
                currNode = currNode.next;
                currIndex++;
            }
        }

        return currNode.value;
    }

    public void forEach(Consumer<Integer> consumer){
        Node currNode = head;
        while (currNode.next!=null){
            consumer.accept(currNode.value);
            currNode = currNode.next;
        }
    }

    public int[]toArray(){
        List<Integer> result = new ArrayList<>();
        forEach(result::add);
        return result.stream().mapToInt(e-> e).toArray();
    }

    private void checkIndex(int searchIndex) {
        if (searchIndex <0|| searchIndex >=size){
            throw new IndexOutOfBoundsException("No such index in the list ");
        }
    }

    private boolean isEmpty(){
        return this.size==0;
    }


}
