package workshop_2_LinkedList;

import java.util.function.Consumer;

public class LinkedList {
    private Node head;
//    private Node Tail;
    private int size;

    public void addFirst(int number){
        Node newNode = new Node(number);
        if (!isEmpty()){
            newNode.next = head;
            }
        head = newNode;
        size++;
    }
    public int removeFirst(){
        if (isEmpty()){
            throw new IllegalStateException("Can`t remove from empty list");
        }
        int result = head.value;
        head = head.next;
        size--;
        return result;
    }
    public void addLast(int number){
        if (isEmpty()){
            addFirst(number);
            return;
        }
        Node newNode = new Node(number);
        Node currNode = head;
        while (currNode.next!=null){
            currNode = currNode.next;
        }
        currNode.next = newNode;
        size++;
    }
    public int removeLast(){
        if (isEmpty()){
            throw new IllegalStateException("Can`t remove from empty list!");
        }
        if (size<2){
            return removeFirst();
        }
        Node currNode = head;
        while (currNode.next.next!=null){
            currNode = currNode.next;
        }
        int result = currNode.next.value;//взимаме стойността на предпосл node
        currNode.next = null;
        size--;
        return result;
    }
    public int get(int searchIndex){
        checkIndex(searchIndex);
        int currIndex = 0;
        Node currNode = head;
        while (currIndex<searchIndex){
            currNode = currNode.next;
            currIndex++;
        }

        return currNode.value;
    }
    public void forEach(Consumer<Integer> consumer){
        Node currNode = head;
        while (currNode.next!=null){
            consumer.accept(currNode.value);
            currNode = currNode.next;
        }
    }
    public int[]toArray(){
        int[] arr = new int[size];
        int counter= 0;
        Node currNode = head;
        while (currNode.next!=null){
            arr[counter] = currNode.value;
            counter++;
            currNode = currNode.next;
        }
        return arr;
    }

    private void checkIndex(int searchIndex) {
        if (searchIndex <0|| searchIndex >=size){
            throw new IndexOutOfBoundsException("No such index in the list ");
        }
    }

    private boolean isEmpty(){
        return this.size==0;
    }


}
