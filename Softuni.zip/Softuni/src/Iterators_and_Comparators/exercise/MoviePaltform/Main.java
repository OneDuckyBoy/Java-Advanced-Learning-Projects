package Iterators_and_Comparators.exercise.MoviePaltform;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Movie> movies =new ArrayList<>();
        Movie movie1 = new Movie("Titanic",15,10);
        Movie movie2 = new Movie("Lord of the rings",25,9);
        Movie movie3 = new Movie("A Softuni Movie",35,8);
        movies.add(movie1);
        movies.add(movie2);
        movies.add(movie3);

//        Comparable -> compareTo -> сравним
        //само един начин на сравн
        //Comparator ->compare ->сравнител
        //създаваме си доп класове
        //можем колкото си искаме начини за сортиране


        MovieNameComparator byName = new MovieNameComparator();
        Collections.sort(movies,byName);
    }
}
