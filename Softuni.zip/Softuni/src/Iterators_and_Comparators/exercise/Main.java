package Iterators_and_Comparators.exercise;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //1. Varargs
        //2. Comparable Comparator
        //3.Iterable Iterator


    }
}
