package Iterators_and_Comparators.exercise.IterableExample;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //Iterable -> нешо, което може да се итерира
        //Iterator -> нещо, което итерира


        Shelf shelf = new Shelf("Apple","Banana","Pear","Watermelon");
        shelf.iterator();

    }
}
