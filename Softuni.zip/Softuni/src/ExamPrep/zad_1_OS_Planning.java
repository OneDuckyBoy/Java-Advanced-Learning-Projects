package ExamPrep;

import java.util.*;
import java.util.stream.Collectors;

public class zad_1_OS_Planning {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        //LIFO stack
        ArrayDeque<Integer> tasks = new ArrayDeque<>();

        Arrays.stream(scanner.nextLine().split(", "))
                .map(Integer::parseInt)
                .forEach(tasks::push);

//        for (Integer task : tasks) {
//            System.out.println(task);
//        }

        //queue
        ArrayDeque<Integer> treads = Arrays.stream(scanner.nextLine().split("\\s+"))
                .map(Integer::parseInt)
                .collect(Collectors.toCollection(ArrayDeque::new));

//        for (Integer tread : treads) {
//            System.out.println(tread);
//        }

        int endTask = Integer.parseInt(scanner.nextLine());

        int task = tasks.peek();
        int tread = treads.peek();
        while (task != endTask){

            if (tread>=task) {
                tasks.pop();
            }
            treads.poll();

            task = tasks.peek();
            tread = treads.peek();
        }
        System.out.printf("Thread with value %d killed task %d%n",treads.peek(),endTask);
        String leftTreads =  treads.stream()
                .map(String::valueOf).collect(Collectors.joining(" "));
        System.out.println(leftTreads);
    }
}
