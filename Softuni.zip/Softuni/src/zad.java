//import java.util.*;
//
//public class zad {
//    public static void main(String[] args) {
//        Scanner scanner = new Scanner(System.in);
//        String[] arr= {"Joe","Alex"};
//
//        System.out.println(whoLikesIt(arr););
//    }
//    public static String whoLikesIt(String... names) {
//        //Do your magic here
//        if(names.length==0){
//            return "no one likes this";
//        }else if(names.length==1){
//            return names[0]+" likes this";
//        }else if(names.length==2){
//            return names[0]+" and "+names[1]+ " like this";
//        }else{
//            int len = names.length-2;
//            return names[0]+", "+names[1]+" and "+len+" others like this";
//        }
//
//    }
//}
