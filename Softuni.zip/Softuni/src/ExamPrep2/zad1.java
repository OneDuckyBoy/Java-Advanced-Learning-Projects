package ExamPrep2;

import java.util.*;
import java.util.stream.Collectors;

public class zad1 {
    public static void main(String[] args) {

        //stack -> push pop peek FIFO

        //queue -> offer poll peek LIFO


        Scanner scanner = new Scanner(System.in);

        ArrayDeque firstBoxQueue = new ArrayDeque<>();
        ArrayDeque secondBoxStack = new ArrayDeque<>();
        int loot =0;

        String input = scanner.nextLine();

        Arrays.stream(input.split(" "))
                .map(Integer::parseInt)
                .forEach(firstBoxQueue::offer);
        Arrays.stream(input.split(" "))
                .map(Integer::parseInt)
                .forEach(secondBoxStack::push);

        while (!firstBoxQueue.isEmpty() &&!secondBoxStack.isEmpty()){
            int firstBoxItem = (int) firstBoxQueue.peek();
            int secondBoxItem = (int)secondBoxStack.pop();

            int sum = firstBoxItem+secondBoxItem;
            if (sum%2==0){
                firstBoxQueue.poll();
                loot+=sum;
            }else {
                firstBoxQueue.offer(secondBoxItem);

            }
        }
        if (firstBoxQueue.isEmpty()){
            System.out.println("First lootbox is empty");
        }else {
            System.out.println("Second lootbox is empty");
        }
        if (loot>=100){
            System.out.println("Your loot was epic! Value: "+loot);
        }else {
            System.out.println("Your loot was poor... Value: "+loot);
        }
    }
}
