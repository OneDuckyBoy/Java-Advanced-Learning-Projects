package help_for_a_friend;

import java.util.*;

public class help {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    }
}
