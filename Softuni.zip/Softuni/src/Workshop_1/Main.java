package Workshop_1;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        SmartArray smartArray = new SmartArray();
        smartArray.add(5);
    }
}
