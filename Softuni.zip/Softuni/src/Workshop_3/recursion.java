package Workshop_3;

import java.util.*;

public class recursion {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

    }
}
