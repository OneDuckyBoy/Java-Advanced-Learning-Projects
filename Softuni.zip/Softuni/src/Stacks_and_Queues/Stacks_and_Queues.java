package Stacks_and_Queues;

import java.util.ArrayDeque;
import java.util.ArrayList;

public class Stacks_and_Queues {

    public static void main(String[] args) {

//        ArrayList<Integer> list = new ArrayList<>();

//        ArrayDeque<Integer> stack = new ArrayDeque<>();
//        stack.push(13);
//        stack.pop();
//        stack.peek();
        //команди за стак
        {//
            //ArrayDeque<Integer> stack = new ArrayDeque<>();
            //stack.push(13);//adding on top of the stack;
            //stack.pop();//see the top el and removing it from the stack
            //stack.peek();//see the top el without removing it
            //stack.contains();
            //stack.isEmpty();
            //stack.size();
        }

        ArrayDeque<Integer> queue = new ArrayDeque<>();
        queue.offer(13);//adds el to the end of the queue
        queue.peek();//returns the front el in the queue without removing it
        queue.poll();//returns the front el in the queue and removes it


        //команди на queue
        {//
//        Queue<String> queue1 = new LinkedList<>();
//        queue1.poll(); // display and delete the first el from the queue
//        queue1.offer("Joe"); // adds an el at the end of the queue
//        queue1.peek(); // sees the first el of the queue but does nоt remove it

//        methods, inherited from the collections class

//        queue1.isEmpty();
//        queue1.size();
//        queue1.contains();

//        queue1.forEach(s -> {
//            System.out.printf("%s is in the queue%n",s);
//        });
//        queue1.clear();
        }





//        int[]arr = {13, 42, 73, 69};
//        int num = 69;
//        boolean containsNum = false;
//        for (int i = 0; i < arr.length; i++) {
//            int currNum = arr[i];
//            if (currNum == num){
//                containsNum = true;
//            }
//        }
//        System.out.println(containsNum);
//
//        int memory = arr.length*Integer.BYTES;
//        System.out.println(memory);
    }


}
