package Stacks_and_Queues.Exersises;

import java.time.OffsetDateTime;
import java.util.*;

public class zad_5_Balanced_Brackets {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String brackets = scanner.nextLine();
        ArrayDeque<Character> stack = new ArrayDeque<>();
        boolean isBalanced = true;
        for (int i = 0; i < brackets.length(); i++) {
            char currBracket = brackets.charAt(i);
            if (currBracket=='('||currBracket=='['||currBracket=='{'){
                stack.push(currBracket);
            }else {
                if (stack.isEmpty()){
                     isBalanced = false;
                     break;
                }
                char lastOpeningBracket = stack.pop();
                if (currBracket=='}'&&lastOpeningBracket!='{'){
                    isBalanced = false;
                }else if (currBracket==']'&&lastOpeningBracket!='['){
                    isBalanced = false;
                }else if (currBracket==')'&&lastOpeningBracket!='('){
                    isBalanced = false;
                }
            }
        }
        if (!stack.isEmpty()){
            isBalanced = false;
        }
        if (isBalanced){
            System.out.println("YES");
        }else {
            System.out.println("NO");
        }
    }
}
