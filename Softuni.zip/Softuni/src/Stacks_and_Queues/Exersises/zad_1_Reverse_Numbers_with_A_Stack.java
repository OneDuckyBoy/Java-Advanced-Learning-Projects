package Stacks_and_Queues.Exersises;

import java.util.*;

public class zad_1_Reverse_Numbers_with_A_Stack {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] numbers = scanner.nextLine().split(" ");
        ArrayDeque<String> stack = new ArrayDeque<>();
        for (String number : numbers) {
            stack.push(number);
        }
        while (!stack.isEmpty()){
            System.out.printf("%s ",stack.pop());
        }
    }
}
