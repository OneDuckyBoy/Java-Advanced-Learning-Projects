package Stacks_and_Queues.Exersises;

import java.util.*;

public class zad_4_Basic_Queue_Operations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split(" ");
        int countToOffer = Integer.parseInt(input[0]);
        int countToPoll = Integer.parseInt(input[1]);
        int elToSearch = Integer.parseInt(input[2]);
        ArrayDeque<Integer> queue = new ArrayDeque<>();

        String[] numToAdd = scanner.nextLine().split(" ");
        for (int i = 0; i < countToOffer; i++) {
            queue.offer(Integer.parseInt(numToAdd[i]));
        }
        for (int i = 0; i < countToPoll; i++) {
            queue.poll();
        }

        if (queue.isEmpty()){
            System.out.println(0);
        }else if (queue.contains(elToSearch)){
            System.out.println(true);
        }else {
//            int min = Integer.MAX_VALUE;
//            for (Integer num :
//                    stack) {
//                if (num < min){
//                    min = num;
//                }
//            }
//            System.out.println(min);

            int minEl = queue.stream().mapToInt(e->e).min().getAsInt();
            System.out.println(minEl);
        }
    }
}
