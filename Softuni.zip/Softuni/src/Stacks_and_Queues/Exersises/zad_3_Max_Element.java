package Stacks_and_Queues.Exersises;

import java.util.*;

public class zad_3_Max_Element {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int num_Of_Commands = Integer.parseInt(scanner.nextLine());
        ArrayDeque<Integer> stack = new ArrayDeque<>();
        for (int i = 0; i < num_Of_Commands; i++) {
            String[] command = scanner.nextLine().split(" ");
            switch (command[0]){
                case "1":
                    stack.push(Integer.parseInt(command[1]));
                    break;
                case "2":
                    stack.pop();
                    break;
                case "3":
                    int maxEl = Collections.max(stack);
                    System.out.println(maxEl);
                    break;
            }
        }
    }
}
