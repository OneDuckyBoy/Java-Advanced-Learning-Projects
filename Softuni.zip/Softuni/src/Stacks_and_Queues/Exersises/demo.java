package Stacks_and_Queues.Exersises;

import java.util.*;

public class demo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        //stack -> push pop peek

        //queue ->offer poll peek


    }
}
