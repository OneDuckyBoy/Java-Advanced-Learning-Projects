package Stacks_and_Queues.Exersises;

import java.util.*;

public class zad_2_Basic_Stack_Operations {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split(" ");
        int index = 0;
        int n = Integer.parseInt(input[index]);index++;
        int s = Integer.parseInt(input[index]);index++;
        int x = Integer.parseInt(input[index]);

        ArrayDeque<Integer> stack = new ArrayDeque<>();
        String[]numbersToAdd = scanner.nextLine().split(" ");
        for (int i = 0; i < n; i++) {
            stack.push(Integer.parseInt(numbersToAdd[i]));
        }
        for (int i = 0; i < s; i++) {
            stack.pop();
        }

        if (stack.isEmpty()){
            System.out.println(0);
        }else if (stack.contains(x)){
            System.out.println(true);
        }else {
//            int min = Integer.MAX_VALUE;
//            for (Integer num :
//                    stack) {
//                if (num < min){
//                    min = num;
//                }
//            }
//            System.out.println(min);

            int minEl = stack.stream().mapToInt(e->e).min().getAsInt();
            System.out.println(minEl);
        }
    }
}
