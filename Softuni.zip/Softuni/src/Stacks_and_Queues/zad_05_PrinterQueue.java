package Stacks_and_Queues;

import java.util.*;

public class zad_05_PrinterQueue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        ArrayDeque printerQueue = new ArrayDeque();

        while (!input.equals("print")){
            if (input.equals("cancel")){
                String output = input.isEmpty() ? "Printer is on standby":"Canceled "+printerQueue.poll();
                System.out.println(output);
            }else {
                printerQueue.offer(input);
            }
            input = scanner.nextLine();
        }
    }
}
