package Sets_and_Maps.exercise;

import java.util.*;

public class zad_1_Unique_Usernames {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
    }
}
