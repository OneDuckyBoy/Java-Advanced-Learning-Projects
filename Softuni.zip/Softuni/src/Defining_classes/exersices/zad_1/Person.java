package Defining_classes.exersices.zad_1;
public class Person {
    String name;
    int age;
}
