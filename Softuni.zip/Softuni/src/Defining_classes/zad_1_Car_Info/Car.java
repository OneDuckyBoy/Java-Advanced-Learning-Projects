package Defining_classes.zad_1_Car_Info;
public class Car {
    private String brand;
    private String model;
    private int horsePower;

    private String color;
    public Car(String brand, String model,int horsePower){
        this.brand = brand;
        this.model = model;
        this.horsePower = horsePower;
    }
    public Car(String brand, String model,int horsePower,String color){
        this(brand, model, horsePower);

        //ако променя във горният конструктор, то ще се промени и тук(поне за бранда, модела и HP)

        this.color = color;
    }


    public String getBrand() {
        return brand;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public String getModel() {
        return model;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setHorsePower(int horsePower) {
        this.horsePower = horsePower;
    }

    @Override
    public String toString() {
        return String.format("The car is %s %s - %d HP.%n",brand,model,horsePower);
    }
}
