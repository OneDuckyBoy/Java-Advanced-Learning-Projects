package Defining_classes.zad_1_Car_Info;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
//        Car car= new Car();
//        car.setBrand("Chevrolet");
//        car.setModel("Impala");
//        car.setHorsePower(390);
//        System.out.printf("The car is %s %s - %d HP.%n",car.getBrand(),car.getModel(),car.getHorsePower());
//        System.out.println(car.toString());
    }
}
