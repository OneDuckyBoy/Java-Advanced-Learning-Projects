package Streams_Files_and_Directories;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

public class zad_1_Read_File {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String path = "resources\\input.txt";
        try {
            FileInputStream fileInputStream = new FileInputStream(path);
            int bytes = fileInputStream.read();
            while (bytes!=-1){

                System.out.print(Integer.toBinaryString(bytes)+ " ");

                bytes = fileInputStream.read();
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
