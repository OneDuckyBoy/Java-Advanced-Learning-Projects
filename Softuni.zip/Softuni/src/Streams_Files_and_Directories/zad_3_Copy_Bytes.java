package Streams_Files_and_Directories;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

public class zad_3_Copy_Bytes {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        String path = "resources\\input.txt";

        FileInputStream inputStream = new FileInputStream(path);
        FileOutputStream outputStream = new FileOutputStream("output.txt");
        int bytes = inputStream.read();
        Set<Integer> delimitersTable = Set.of(10,32);

        PrintWriter printer = new PrintWriter(outputStream);

        while (bytes!=-1){


            boolean isDelimiter = delimitersTable.contains(bytes);



            if (isDelimiter){
                printer.print((char) bytes);
            }else {
                printer.print(bytes);
            }

            bytes = inputStream.read();
        }
        inputStream.close();
        outputStream.close();

    }
}
