package Streams_Files_and_Directories;

import java.io.*;
import java.util.*;

public class zad_5_Write_Every_Third_Line {
    public static void main(String[] args) throws IOException {
        String path = "resources\\input.txt";

        FileInputStream inputStream = new FileInputStream(path);

//        Scanner scanner = new Scanner(inputStream);

        BufferedReader reader;
        reader = new BufferedReader(new InputStreamReader(inputStream));

        String line = reader.readLine();

        int lineCounter = 1;

        while (line!=null){
            if (lineCounter%3==0){
                System.out.println(line);
            }
                line = reader.readLine();
            lineCounter++;

        }
    }
}
