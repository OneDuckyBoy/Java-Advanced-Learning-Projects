package Streams_Files_and_Directories;

        import java.io.FileInputStream;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.util.*;

public class zad_2_Write_to_File {
    public static void main(String[] args) throws IOException {
        Scanner scanner = new Scanner(System.in);
        String path = "resources\\input.txt";

        FileInputStream inputStream = new FileInputStream(path);
        FileOutputStream outputStream = new FileOutputStream("output.txt");
        int bytes = inputStream.read();
        Set<Character> punctuationTable = Set.of(',','.','!','?');
        while (bytes!=-1){

            char symbol = (char)bytes;

            boolean isPunctuation = punctuationTable.contains(symbol);

            if (!isPunctuation){
                outputStream.write(symbol);
            }

            bytes = inputStream.read();
        }

    }
}
