package Streams_Files_and_Directories;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.util.*;
import java.io.*;

public class zad_4_Extract_Integers {
    public static void main(String[] args) throws IOException {
        String path = "resources\\input.txt";

        FileInputStream inputStream = new FileInputStream(path);

        Scanner scanner = new Scanner(inputStream);

        while (scanner.hasNext()){
            if (scanner.hasNextInt()){
                System.out.println(scanner.nextInt());
            }else {
                scanner.next();
            }
        }
    }
}

/*
1
1533
3
4
5
1600
6
7
1533
8
*/
