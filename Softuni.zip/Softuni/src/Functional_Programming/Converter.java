package Functional_Programming;

public interface Converter {

    String transformString(String text);
}
