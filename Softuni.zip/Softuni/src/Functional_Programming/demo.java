package Functional_Programming;

import java.util.*;
import java.util.function.*;

public class demo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Converter converter = text -> text+ " bye";
        //функционални интерфейси

        //Function<приема, връща>
        //UnaryOperator<приема и връща>
        //Predicate<приема> и винаги връща boolean
        //Consumer<приема> и не връща нишо
        //Supplier<връща>
    }
}
