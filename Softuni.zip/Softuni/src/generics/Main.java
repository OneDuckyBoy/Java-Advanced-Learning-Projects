package generics;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] input = scanner.nextLine().split(" ");
        String name = input[0]+input[1];
        String city = input[2];
        Tuple<String, String> firstTuple= new Tuple<>(name,city);
        System.out.println(firstTuple.toString());

        input = scanner.nextLine().split(" ");
        String firstName = input[0];
        int grade = Integer.parseInt(input[1]);
        Tuple<String,Integer> secondTuple = new Tuple<>(firstName,grade);
        System.out.println(secondTuple.toString());

        input = scanner.nextLine().split(" ");
        int num = Integer.parseInt(input[0]);
        double doubl = Double.parseDouble(input[1]);
        Tuple<Integer,Double> thirdTuple = new Tuple<>(num,doubl);
        System.out.println(thirdTuple.toString());


    }
}
