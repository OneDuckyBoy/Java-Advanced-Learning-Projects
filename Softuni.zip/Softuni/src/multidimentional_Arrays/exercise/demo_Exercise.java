package multidimentional_Arrays.exercise;

import java.util.*;

public class demo_Exercise {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int row = 2;
        int col = 3;
        int[][] matrix = new int[row][col];

        readMatrixWithForLoop(scanner, row, col, matrix);

        readMatrixWithStreamAPI(scanner, row, matrix);

        printMatrixWithLoop(row, col, matrix);

        printMatrixWithForeach(matrix);
    }

    public static void printMatrixWithForeach(int[][] matrix) {
        for (int[] rows :
                matrix) {
            for (int element :
                    rows) {
                System.out.println(element+" ");
            }
            System.out.println();
        }
    }

    public static void printMatrixWithLoop(int row, int col, int[][] matrix) {
        for (int rows = 0; rows < row; rows++) {
            for (int cols = 0; cols < col; cols++) {
                System.out.println(matrix[rows][cols]);
            }
            System.out.println();
        }
    }

    public static void readMatrixWithStreamAPI(Scanner scanner, int row, int[][] matrix) {
        for (int rows = 0; rows < row; rows++) {
            matrix[rows] = Arrays.stream(scanner.nextLine().split(" "))
                    .mapToInt(Integer::parseInt)
                    .toArray();
        }
    }

    public static void readMatrixWithForLoop(Scanner scanner, int row, int col, int[][] matrix) {
        for (int rows = 0; rows < row; rows++) {
            String[] rowsFromConsole = scanner.nextLine().split(" ");
            for (int cols = 0; cols < col; cols++) {
                matrix[rows][cols] = Integer.parseInt(rowsFromConsole[cols]);
            }
        }
    }
}
