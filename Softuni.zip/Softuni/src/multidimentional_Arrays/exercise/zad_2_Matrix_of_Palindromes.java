package multidimentional_Arrays.exercise;

import java.util.*;

public class zad_2_Matrix_of_Palindromes {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] matrixSize = scanner.nextLine().split(" ");
        int rows = Integer.parseInt(matrixSize[0]);
        int cols = Integer.parseInt(matrixSize[1]);

        String[][] matrix = new String[rows][cols];

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                //enter palindrome
                char outsideLetter = (char) ('a'+row);
                char insideLetter = (char) ('a'+row+col);
                matrix[row][col] = ""+outsideLetter +insideLetter+outsideLetter;
            }
        }
        //print matrix

        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < cols; col++) {
                System.out.print(matrix[row][col]+" ");
            }
            System.out.println();
        }
    }
}
